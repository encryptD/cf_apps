sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, Filter, FilterOperator, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("com.mdasad.gatepass.controller.GateExit", {

        onInit: function () {
            var oModel = new JSONModel({
                gateEntry_ID: "",
                gateEntryNumber: "",
                gatePass_ID: "",
                gatePassNumber: "",
                exitDate: new Date(),
                exitTime: null,
                securityOfficer: "",
                remarks: ""
            });
            this.getView().setModel(oModel, "exit");

            this.getOwnerComponent().getRouter().getRoute("GateExit").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            this._clearForm();
            this._loadPassIssuedEntries();
        },

        _clearForm: function () {
            var oModel = this.getView().getModel("exit");
            oModel.setProperty("/gateEntry_ID", "");
            oModel.setProperty("/gateEntryNumber", "");
            oModel.setProperty("/gatePass_ID", "");
            oModel.setProperty("/gatePassNumber", "");
            oModel.setProperty("/exitDate", new Date());
            oModel.setProperty("/exitTime", null);
            oModel.setProperty("/securityOfficer", "");
            oModel.setProperty("/remarks", "");
        },

        _loadPassIssuedEntries: function () {
            var oODataModel = this.getView().getModel();
            if (!oODataModel) {
                return;
            }
            var oListBinding = oODataModel.bindList("/GateEntries");
            oListBinding.filter(new Filter("entryStatus", FilterOperator.EQ, "PASS_ISSUED"));
            oListBinding.requestContexts(0, Infinity).then(function (aContexts) {
                var aResults = aContexts.map(function (oContext) {
                    return oContext.getObject();
                });
                var oModel = this.getView().getModel("exit");
                oModel.setProperty("/passIssuedEntries", aResults);
            }.bind(this)).catch(function () {
                MessageToast.show("Could not load Gate Entries");
            });
        },

        _loadGatePassesForEntry: function (sGateEntryID) {
            var oODataModel = this.getView().getModel();
            if (!oODataModel || !sGateEntryID) {
                return;
            }
            var oListBinding = oODataModel.bindList("/GatePasses");
            oListBinding.filter(new Filter("gateEntry_ID", FilterOperator.EQ, sGateEntryID));
            oListBinding.requestContexts(0, Infinity).then(function (aContexts) {
                var aResults = aContexts.map(function (oContext) {
                    return oContext.getObject();
                });
                var oModel = this.getView().getModel("exit");
                oModel.setProperty("/gatePasses", aResults);
            }.bind(this)).catch(function () {
                MessageToast.show("Could not load Gate Passes");
            });
        },

        onGateEntryChange: function (oEvent) {
            var sSelectedKey = oEvent.getParameter("selectedItem")?.getKey();
            if (!sSelectedKey) {
                return;
            }
            var oModel = this.getView().getModel("exit");
            var oODataModel = this.getView().getModel();

            var oContextBinding = oODataModel.bindContext("/GateEntries('" + sSelectedKey + "')");
            oContextBinding.requestObject().then(function (oData) {
                oModel.setProperty("/gateEntry_ID", oData.ID);
                oModel.setProperty("/gateEntryNumber", oData.gateEntryNumber);
                this._loadGatePassesForEntry(oData.ID);
            }.bind(this)).catch(function () {
                MessageToast.show("Could not fetch Gate Entry details");
            });
        },

        onGatePassChange: function (oEvent) {
            var sSelectedKey = oEvent.getParameter("selectedItem")?.getKey();
            if (!sSelectedKey) {
                return;
            }
            var oModel = this.getView().getModel("exit");
            oModel.setProperty("/gatePass_ID", sSelectedKey);
            oModel.setProperty("/gatePassNumber", oEvent.getParameter("selectedItem").getText());
        },

        onClosePress: function () {
            var oModel = this.getView().getModel("exit");
            var oData = oModel.getData();

            if (!oData.gateEntry_ID) {
                MessageBox.error("Gate Entry is mandatory");
                return;
            }
            if (!oData.gatePass_ID) {
                MessageBox.error("Gate Pass is mandatory");
                return;
            }

            var oODataModel = this.getView().getModel();
            var oAction = oODataModel.bindContext("/closeGateEntry(...)");
            oAction.setParameter("gateEntryID", oData.gateEntry_ID);
            oAction.setParameter("gatePassID", oData.gatePass_ID);
            oAction.execute().then(function () {
                var oResponse = oAction.getBoundContext().getObject();
                MessageBox.success("Gate Entry closed successfully: " + (oResponse && oResponse.gateEntryNumber));
                this._clearForm();
                this._loadPassIssuedEntries();
            }.bind(this)).catch(function (oError) {
                var sMessage = oError.message || "Error closing Gate Entry";
                MessageBox.error(sMessage);
            }.bind(this));
        },

        onCancelPress: function () {
            this._clearForm();
            MessageToast.show("Form cleared");
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("Dashboard");
        }
    });
});
