sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("com.mdasad.gatepass.controller.GateEntryList", {

        onInit: function () {
            var oModel = new JSONModel({
                mode: "Create",
                movementType: "I",
                referenceType: "PO",
                referenceNumber: "",
                plant: "",
                partyNumber: "",
                partyName: "",
                vehicleNumber: "",
                vehicleType: "",
                transporterNumber: "",
                transporterName: "",
                driverName: "",
                driverContact: "",
                lrNumber: "",
                entryDate: new Date(),
                entryTime: null,
                remarks: ""
            });
            this.getView().setModel(oModel, "entry");

            // OData model will be set from manifest
            this.getOwnerComponent().getRouter().getRoute("GateEntryList").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            this._clearForm();
        },

        _clearForm: function () {
            var oModel = this.getView().getModel("entry");
            oModel.setProperty("/mode", "Create");
            oModel.setProperty("/movementType", "I");
            oModel.setProperty("/referenceType", "PO");
            oModel.setProperty("/referenceNumber", "");
            oModel.setProperty("/plant", "");
            oModel.setProperty("/partyNumber", "");
            oModel.setProperty("/partyName", "");
            oModel.setProperty("/vehicleNumber", "");
            oModel.setProperty("/vehicleType", "");
            oModel.setProperty("/transporterNumber", "");
            oModel.setProperty("/transporterName", "");
            oModel.setProperty("/driverName", "");
            oModel.setProperty("/driverContact", "");
            oModel.setProperty("/lrNumber", "");
            oModel.setProperty("/entryDate", new Date());
            oModel.setProperty("/entryTime", null);
            oModel.setProperty("/remarks", "");
        },

        formatReferenceType: function (sMovementType) {
            var oI18nModel = this.getView().getModel("i18n") || this.getOwnerComponent().getModel("i18n");
            if (!oI18nModel) {
                return sMovementType === "I" ? "Purchase Order" : "Sales Invoice";
            }
            var oBundle = oI18nModel.getResourceBundle();
            return sMovementType === "I" ? oBundle.getText("purchaseOrder") : oBundle.getText("salesInvoice");
        },

        formatPlaceholder: function (sMovementType) {
            var oI18nModel = this.getView().getModel("i18n") || this.getOwnerComponent().getModel("i18n");
            if (!oI18nModel) {
                return sMovementType === "I" ? "Enter PO Number" : "Enter Invoice Number";
            }
            var oBundle = oI18nModel.getResourceBundle();
            return sMovementType === "I" ? oBundle.getText("enterPONumber") : oBundle.getText("enterInvoiceNumber");
        },

        onMovementTypeChange: function (oEvent) {
            var oModel = this.getView().getModel("entry");
            var sMovement = oEvent.getParameter("selectedIndex") === 0 ? "I" : "O";
            oModel.setProperty("/movementType", sMovement);
            oModel.setProperty("/referenceType", sMovement === "I" ? "PO" : "SI");
        },

        onReferenceNumberChange: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            var oModel = this.getView().getModel("entry");
            var sMovement = oModel.getProperty("/movementType");

            if (!sValue) {
                return;
            }

            // Call backend to fetch PO/Invoice details
            var oODataModel = this.getView().getModel();
            var sFunction = sMovement === "I" ? "getPurchaseOrderDetails" : "getSalesInvoiceDetails";
            var sParamName = sMovement === "I" ? "poNumber" : "invoiceNumber";

            var oFunction = oODataModel.bindContext("/" + sFunction + "(...)");
            oFunction.setParameter(sParamName, sValue);
            oFunction.requestObject().then(function (oData) {
                oModel.setProperty("/plant", oData.plant);
                oModel.setProperty("/partyNumber", oData.supplierNumber || oData.customerNumber);
                oModel.setProperty("/partyName", oData.supplierName || oData.customerName);
                MessageToast.show("Details fetched successfully");
            }).catch(function () {
                MessageToast.show("Could not fetch details. Please enter manually.");
            });
        },

        onSavePress: function () {
            var oModel = this.getView().getModel("entry");
            var oData = oModel.getData();

            // Mandatory validations
            if (!oData.referenceNumber) {
                MessageBox.error("Reference Number (PO/Invoice) is mandatory");
                return;
            }
            if (!oData.vehicleNumber) {
                MessageBox.error("Vehicle Number is mandatory");
                return;
            }
            if (!oData.plant) {
                MessageBox.error("Plant is mandatory");
                return;
            }
            if (!oData.transporterName) {
                MessageBox.error("Transporter Name is mandatory");
                return;
            }
            if (!oData.entryDate) {
                MessageBox.error("Entry Date is mandatory");
                return;
            }

            var oODataModel = this.getView().getModel();
            var oPayload = {
                movementType: oData.movementType,
                referenceType: oData.referenceType,
                referenceNumber: oData.referenceNumber,
                plant: oData.plant,
                partyNumber: oData.partyNumber,
                partyName: oData.partyName,
                vehicleNumber: oData.vehicleNumber,
                vehicleType: oData.vehicleType,
                transporterNumber: oData.transporterNumber,
                transporterName: oData.transporterName,
                driverName: oData.driverName,
                driverContact: oData.driverContact,
                lrNumber: oData.lrNumber,
                entryDate: oData.entryDate,
                entryTime: oData.entryTime,
                remarks: oData.remarks
            };

            var oListBinding = oODataModel.bindList("/GateEntries");
            var oContext = oListBinding.create(oPayload);

            oContext.created().then(function () {
                var oResponse = oContext.getObject();
                MessageBox.success("Gate Entry created: " + oResponse.gateEntryNumber);
                this._clearForm();
            }.bind(this)).catch(function (oError) {
                var sMessage = oError.message || "Error creating Gate Entry";
                MessageBox.error(sMessage);
            }.bind(this));
        },

        onCancelPress: function () {
            this._clearForm();
            MessageToast.show("Form cleared");
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("Dashboard");
        }
    });
});