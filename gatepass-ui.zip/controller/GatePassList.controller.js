sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, Filter, FilterOperator, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("com.mdasad.gatepass.controller.GatePassList", {

        onInit: function () {
            var oModel = new JSONModel({
                mode: "Create",
                movementType: "I",
                gateEntry_ID: "",
                gateEntryNumber: "",
                referenceType: "",
                referenceNumber: "",
                partyNumber: "",
                partyName: "",
                invoiceDate: null,
                invoiceValue: "",
                eWayBillNumber: "",
                eWayBillDate: null,
                shippingAddress: "",
                vehicleNumber: "",
                vehicleType: "",
                transporterName: "",
                driverName: "",
                lrNumber: "",
                passDate: new Date(),
                passTime: null,
                remarks: "",
                items: []
            });
            this.getView().setModel(oModel, "pass");

            this.getOwnerComponent().getRouter().getRoute("GatePassList").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            this._clearForm();
            this._loadOpenGateEntries();
        },

        _clearForm: function () {
            var oModel = this.getView().getModel("pass");
            oModel.setProperty("/mode", "Create");
            oModel.setProperty("/gateEntry_ID", "");
            oModel.setProperty("/gateEntryNumber", "");
            oModel.setProperty("/referenceType", "");
            oModel.setProperty("/referenceNumber", "");
            oModel.setProperty("/partyNumber", "");
            oModel.setProperty("/partyName", "");
            oModel.setProperty("/invoiceDate", null);
            oModel.setProperty("/invoiceValue", "");
            oModel.setProperty("/eWayBillNumber", "");
            oModel.setProperty("/eWayBillDate", null);
            oModel.setProperty("/shippingAddress", "");
            oModel.setProperty("/vehicleNumber", "");
            oModel.setProperty("/vehicleType", "");
            oModel.setProperty("/transporterName", "");
            oModel.setProperty("/driverName", "");
            oModel.setProperty("/lrNumber", "");
            oModel.setProperty("/passDate", new Date());
            oModel.setProperty("/passTime", null);
            oModel.setProperty("/remarks", "");
            oModel.setProperty("/items", []);
        },

        _loadOpenGateEntries: function () {
            var oODataModel = this.getView().getModel();
            if (!oODataModel) {
                return;
            }
            var oListBinding = oODataModel.bindList("/GateEntries");
            oListBinding.filter(new Filter("entryStatus", FilterOperator.EQ, "CREATED"));
            oListBinding.requestContexts(0, Infinity).then(function (aContexts) {
                var aResults = aContexts.map(function (oContext) {
                    return oContext.getObject();
                });
                var oModel = this.getView().getModel("pass");
                oModel.setProperty("/gateEntries", aResults);
            }.bind(this)).catch(function () {
                MessageToast.show("Could not load Gate Entries");
            });
        },

        onGateEntryChange: function (oEvent) {
            var sSelectedKey = oEvent.getParameter("selectedItem")?.getKey();
            if (!sSelectedKey) {
                return;
            }
            var oModel = this.getView().getModel("pass");
            var oODataModel = this.getView().getModel();

            var oContextBinding = oODataModel.bindContext("/GateEntries('" + sSelectedKey + "')");
            oContextBinding.requestObject().then(function (oData) {
                oModel.setProperty("/gateEntry_ID", oData.ID);
                oModel.setProperty("/gateEntryNumber", oData.gateEntryNumber);
                oModel.setProperty("/movementType", oData.movementType);
                oModel.setProperty("/referenceType", oData.referenceType);
                oModel.setProperty("/referenceNumber", oData.referenceNumber);
                oModel.setProperty("/partyNumber", oData.partyNumber);
                oModel.setProperty("/partyName", oData.partyName);
                oModel.setProperty("/vehicleNumber", oData.vehicleNumber);
                oModel.setProperty("/vehicleType", oData.vehicleType);
                oModel.setProperty("/transporterName", oData.transporterName);
                oModel.setProperty("/driverName", oData.driverName);
                oModel.setProperty("/lrNumber", oData.lrNumber);
            }).catch(function () {
                MessageToast.show("Could not fetch Gate Entry details");
            });
        },

        formatReferenceType: function (sMovementType) {
            var oI18nModel = this.getView().getModel("i18n") || this.getOwnerComponent().getModel("i18n");
            if (!oI18nModel) {
                return sMovementType === "I" ? "Purchase Order" : "Sales Invoice";
            }
            var oBundle = oI18nModel.getResourceBundle();
            return sMovementType === "I" ? oBundle.getText("purchaseOrder") : oBundle.getText("salesInvoice");
        },

        onAddItem: function () {
            var oModel = this.getView().getModel("pass");
            var aItems = oModel.getProperty("/items") || [];
            aItems.push({
                itemNumber: aItems.length + 1,
                materialCode: "",
                materialDescription: "",
                quantity: "",
                unitOfMeasure: "",
                supplierInvoiceNo: "",
                supplierInvoiceDate: null,
                orderItemNumber: ""
            });
            oModel.setProperty("/items", aItems);
        },

        onRemoveItem: function (oEvent) {
            var oModel = this.getView().getModel("pass");
            var aItems = oModel.getProperty("/items") || [];
            var iIndex = parseInt(oEvent.getSource().data("index"), 10) - 1;
            aItems.splice(iIndex, 1);
            aItems.forEach(function (item, idx) {
                item.itemNumber = idx + 1;
            });
            oModel.setProperty("/items", aItems);
        },

        onSavePress: function () {
            var oModel = this.getView().getModel("pass");
            var oData = oModel.getData();

            if (!oData.gateEntry_ID) {
                MessageBox.error("Gate Entry is mandatory");
                return;
            }
            if (!oData.vehicleNumber) {
                MessageBox.error("Vehicle Number is mandatory");
                return;
            }
            if (!oData.passDate) {
                MessageBox.error("Pass Date is mandatory");
                return;
            }

            var aItems = oData.items || [];
            if (aItems.length === 0) {
                MessageBox.error("At least one material item is required");
                return;
            }

            for (var i = 0; i < aItems.length; i++) {
                if (!aItems[i].materialCode) {
                    MessageBox.error("Material Code is mandatory for all items");
                    return;
                }
                if (!aItems[i].materialDescription) {
                    MessageBox.error("Material Description is mandatory for all items");
                    return;
                }
                if (!aItems[i].quantity) {
                    MessageBox.error("Quantity is mandatory for all items");
                    return;
                }
            }

            var oODataModel = this.getView().getModel();
            var oPayload = {
                gateEntry_ID: oData.gateEntry_ID,
                vehicleNumber: oData.vehicleNumber,
                vehicleType: oData.vehicleType,
                transporterName: oData.transporterName,
                driverName: oData.driverName,
                lrNumber: oData.lrNumber,
                invoiceDate: oData.invoiceDate,
                invoiceValue: oData.invoiceValue ? parseFloat(oData.invoiceValue) : null,
                eWayBillNumber: oData.eWayBillNumber,
                eWayBillDate: oData.eWayBillDate,
                shippingAddress: oData.shippingAddress,
                passDate: oData.passDate,
                passTime: oData.passTime,
                remarks: oData.remarks,
                items: aItems.map(function (item) {
                    return {
                        itemNumber: item.itemNumber,
                        materialCode: item.materialCode,
                        materialDescription: item.materialDescription,
                        quantity: parseFloat(item.quantity),
                        unitOfMeasure: item.unitOfMeasure,
                        supplierInvoiceNo: item.supplierInvoiceNo,
                        supplierInvoiceDate: item.supplierInvoiceDate,
                        orderItemNumber: item.orderItemNumber
                    };
                })
            };

            var oListBinding = oODataModel.bindList("/GatePasses");
            var oContext = oListBinding.create(oPayload);

            oContext.created().then(function () {
                var oResponse = oContext.getObject();
                MessageBox.success("Gate Pass created: " + oResponse.gatePassNumber);
                this._clearForm();
            }.bind(this)).catch(function (oError) {
                var sMessage = oError.message || "Error creating Gate Pass";
                MessageBox.error(sMessage);
            }.bind(this));
        },

        onCancelPress: function () {
            this._clearForm();
            MessageToast.show("Form cleared");
        },

        onPrintPress: function () {
            var oModel = this.getView().getModel("pass");
            var sGatePassID = oModel.getProperty("/gatePassID");
            if (!sGatePassID) {
                MessageBox.error("Please save the Gate Pass first");
                return;
            }
            var oODataModel = this.getView().getModel();
            var oAction = oODataModel.bindContext("/printGatePass(...)");
            oAction.setParameter("gatePassID", sGatePassID);
            oAction.execute().then(function () {
                var oResult = oAction.getBoundContext().getObject();
                MessageToast.show("Print data generated");
                console.log(oResult);
            }).catch(function () {
                MessageBox.error("Failed to generate print");
            });
        },

        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("Dashboard");
        }
    });
});
